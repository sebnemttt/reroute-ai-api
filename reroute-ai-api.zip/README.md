# ReRoute AI — Skorlama API

Bu, ReRoute AI'nin IRROPS öncelik skorlama motorunun gerçek backend'idir (Node.js, Vercel serverless functions).

## İçerik
- `api/score.js` — Tek yolcu için skor hesaplayan endpoint (`POST /api/score`)
- `api/batch-score.js` — Çoklu yolcu listesini aynı anda skorlayıp sıralayan endpoint (`POST /api/batch-score`)
- `public/index.html` — API'nin ana sayfası (kullanım talimatları gösterir)
- `vercel.json` — Vercel yapılandırması

## Vercel'e Deploy Etme (yaklaşık 10-15 dakika)

### Yöntem 1: Vercel CLI ile (önerilen)
1. [vercel.com](https://vercel.com) üzerinde ücretsiz bir hesap açın (GitHub ile giriş yapabilirsiniz).
2. Bilgisayarınızda bu klasörü açın, terminalde şu komutları çalıştırın:
   ```
   npm install -g vercel
   vercel login
   vercel
   ```
3. Sorulan soruları varsayılan ayarlarla geçebilirsiniz (Enter'a basmak genelde yeterli).
4. İşlem bitince terminalde size bir URL verilecek, örneğin:
   `https://reroute-ai-api.vercel.app`
5. Bu URL'yi tarayıcınızda açtığınızda kullanım talimatlarını göreceksiniz.

### Yöntem 2: GitHub + Vercel Dashboard ile (CLI kullanmadan)
1. Bu klasörü bir GitHub reposuna yükleyin.
2. [vercel.com/new](https://vercel.com/new) adresine gidin, GitHub hesabınızla giriş yapın.
3. "Import Project" diyerek bu reponuzu seçin.
4. Hiçbir ayarı değiştirmeden "Deploy" butonuna basın.
5. 1-2 dakika içinde size bir canlı URL verilecek.

## Test Etme

Deploy ettikten sonra, tarayıcıdan veya bir API test aracından (Postman, Insomnia, veya basitçe terminalden `curl`) şu örnekleri deneyebilirsiniz:

### Tek yolcu skoru
```bash
curl -X POST https://SIZIN-URL.vercel.app/api/score \
  -H "Content-Type: application/json" \
  -d '{"tier":"Elite Plus","connMin":38,"cabin":"Business","special":false}'
```

### Toplu yolcu skorlama
```bash
curl -X POST https://SIZIN-URL.vercel.app/api/batch-score \
  -H "Content-Type: application/json" \
  -d '{"passengers":[
    {"name":"Elif Yıldırım","tier":"Elite Plus","connMin":38,"cabin":"Business","special":false},
    {"name":"Sarah Connors","tier":"Classic","connMin":70,"cabin":"Economy Comfort","special":true}
  ]}'
```

## Parametreler

| Alan | Tip | Olası Değerler |
|---|---|---|
| `tier` | string | `"Elite Plus"`, `"Elite"`, `"Classic"` |
| `connMin` | number | Dakika cinsinden kalan bağlantı süresi (örn: 38) |
| `cabin` | string | `"Business"`, `"Economy Comfort"`, `"Economy"` |
| `special` | boolean | Özel hizmet ihtiyacı var mı (`true`/`false`) |

## Skorlama Formülü

```
Toplam Skor = (Sadakat × 0.35) + (Bağlantı Riski × 0.35) + (Bilet Sınıfı × 0.20) + (Özel İhtiyaç × 0.10)
```

Bağlantı Riski, kalan bağlantı süresine ters orantılı hesaplanır: süre ≤20 dakikaysa risk maksimum (100), süre ≥240 dakikaysa risk minimum (0)'dır.

## Not

Bu API, demo (`reroute-ai-demo.html`) ile aynı skorlama mantığını sunucu tarafında çalıştırır. Demo şu an client-side (tarayıcı içinde) çalışıyor; bu API, "gerçek bir backend'imiz var, internetten erişilebilir ve test edilebilir" iddiasını kanıtlamak için ayrı olarak hazırlanmıştır. İstenirse demo, bu API'ye bağlanacak şekilde de güncellenebilir.
